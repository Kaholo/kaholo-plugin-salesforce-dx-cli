# kaholo-plugin-template
A template repository for Kaholo plugins.
